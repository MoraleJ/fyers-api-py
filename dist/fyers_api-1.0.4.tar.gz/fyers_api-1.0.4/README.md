README
========

Packages Required
json
requests
tornado 

For an overview of Fyers-api please refer to the documentation at http://apidashboard.fyers.in/api-docs
